# 配置项清单

## 1. 环境变量
### 必看
- `TZ`
- `BINANCE_FUTURES_BASE_URL`
- `BINANCE_PROXY_URL`
- `ALT_RISK_PROXY_URL`
- `ALT_RISK_LOG_LEVEL`

### 采集相关
- `ALT_RISK_REQUEST_TIMEOUT_MS`
- `ALT_RISK_CONCURRENCY`
- `ALT_RISK_DEPTH_LIMIT`
- `ALT_RISK_HISTORY_WINDOW_BARS`
- `ALT_RISK_EXCLUDED_SYMBOLS`

### 调度相关
- `MONITOR_LOOP_SLEEP_SECONDS`
- `REPORT_LOOP_SLEEP_SECONDS`
- `DAILY_REPORT_HOUR_UTC`
- `DAILY_REPORT_MINUTE_UTC`
- `WEEKLY_REPORT_DAY_UTC`
- `WEEKLY_REPORT_HOUR_UTC`
- `WEEKLY_REPORT_MINUTE_UTC`

### 健康与备份
- `HEALTHCHECK_MAX_AGE_SECONDS`
- `BACKUP_KEEP_DAYS`

## 2. 端口占用
- 当前最小部署版：**无对外监听端口**
- 当前没有独立 HTTP 服务，也没有数据库监听端口

## 3. 数据目录
默认以 `deploy/alt_futures_risk_monitor_v1/runtime` 为宿主机根目录：
- `runtime/data`
- `runtime/reports`
- `runtime/logs`
- `runtime/backups`

容器内固定挂载为：
- `/app/data`
- `/app/reports`
- `/app/logs`
- `/app/backups`

## 4. 日志目录
- 宿主机：`./runtime/logs/alt_futures_risk_monitor_v1`
- 容器内：`/app/logs/alt_futures_risk_monitor_v1`

## 5. 备份目录
- 宿主机：`./runtime/backups`
- 容器内：`/app/backups`

## 6. 定时任务
当前不是系统 cron，而是容器内 loop：
- monitor：
  - 1 分钟闭合节奏
  - 持续运行
- daily report：
  - 默认 UTC `00:10`
- weekly report：
  - 默认周一 UTC `00:15`
- backup：
  - 当前提供脚本
  - 建议宿主机 cron 每日执行一次

## 7. 需要人工填写的配置项
- `.env` 中代理配置是否需要
- `.env` 中是否排除额外 symbol
- 日报 / 周报执行时间
- 服务器时区
- 备份保留天数
