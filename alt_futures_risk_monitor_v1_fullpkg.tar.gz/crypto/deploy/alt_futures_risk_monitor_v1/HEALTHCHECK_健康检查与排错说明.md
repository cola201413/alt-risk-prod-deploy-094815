# 健康检查与排错说明

## 1. 本地 order book 不同步时怎么看
重点看：
- `risk_eval_snapshot_1m_v1_current.json`
- `risk_eval_snapshot_1m_v1.jsonl`

关键字段：
- `quality.orderbookSyncOk`
- `quality.orderbookAgeMs`
- `quality.degradeReasons`

异常特征：
- `orderbookSyncOk = false`
- `orderbookAgeMs` 持续过大
- `degradeReasons` 出现：
  - `orderbook_not_fresh`

排查顺序：
1. 先看容器日志里是否有 Binance 上游请求失败
2. 再看 `dynamic_pool_current.json` 是否仍在刷新
3. 再看 `books/current` 和 `books/history` 是否还在写入

## 2. WebSocket 断连时怎么看
当前实现实际使用的是 REST depth + book ticker / premium index 组合，不是独立常驻 WS 服务。
所以“断连”更多表现为：
- 上游请求异常
- `orderbookAgeMs` 变大
- `marketAgeMs` 变大
- `Binance 418` 或 timeout

重点检查：
- `monitor.loop.log`
- `docker compose logs -f alt-risk-runner`

## 3. 数据库是否正常写入怎么看
当前数据库是文件型状态库，不是 SQL 服务。

看这些文件是否持续增长或更新时间刷新：
- `runtime/data/alt_futures_risk_monitor_v1/dynamic_pool_current.json`
- `runtime/data/alt_futures_risk_monitor_v1/risk_eval_snapshot_1m_v1.jsonl`
- `runtime/data/alt_futures_risk_monitor_v1/risk_event_stream_v1.jsonl`
- `runtime/data/alt_futures_risk_monitor_v1/risk_event_group_v1_current.json`

如果这些文件不更新，优先检查：
1. 容器是否在跑
2. monitor loop 是否异常退出
3. 上游是否被 `418` 或 timeout 拦住

## 4. 事件流是否正常产出怎么看
重点看：
- `risk_event_stream_v1.jsonl`
- `risk_event_group_v1_current.json`
- `risk_symbol_daily_summary_v1.json`

正常时应看到：
- event stream 有 `open / escalate / refresh / deescalate / close`
- event group current 能看到 `event_group_id`
- daily / weekly summary 能产出 `DOGEUSDT / SOLUSDT` 之类已命中样本

## 5. 常见报错排查顺序
### A. `418`
结论：
- 这是外部环境 / 运行风险
- 不是规则错误

顺序：
1. 确认服务器公网出口是否被 Binance 拦截
2. 如有必要，加代理并填写：
  - `BINANCE_PROXY_URL`
  - 或 `ALT_RISK_PROXY_URL`
3. 重跑 monitor，看 `failureCount` 是否下降

### B. 报表不更新
顺序：
1. 看 `reports.loop.log`
2. 看 `.env` 中日报 / 周报时间配置
3. 手动执行：
   - `docker compose exec alt-risk-runner node scripts/alt_futures_risk_report_daily.js`
   - `docker compose exec alt-risk-runner node scripts/alt_futures_risk_report_weekly.js`

### C. healthcheck fail
顺序：
1. 看 `HEALTHCHECK_MAX_AGE_SECONDS` 是否太小
2. 看 `risk_eval_snapshot_1m_v1.jsonl` 是否最近有更新
3. 看容器是否刚启动、尚未完成首轮采集

### D. 备份 / 恢复失败
顺序：
1. 确认容器已停止
2. 确认备份包路径正确
3. 确认恢复目标目录权限正常
4. 恢复后再 `docker compose up -d`
