#!/usr/bin/env bash
set -euo pipefail

APP_HOME="${APP_HOME:-/app}"
DEPLOY_HOME="$APP_HOME/deploy/alt_futures_risk_monitor_v1"

"$DEPLOY_HOME/database/001_init_filesystem_store.sh"

"$DEPLOY_HOME/scripts/run_monitor_loop.sh" &
MONITOR_PID=$!

"$DEPLOY_HOME/scripts/run_reports_loop.sh" &
REPORT_PID=$!

graceful_shutdown() {
  kill -TERM "$MONITOR_PID" "$REPORT_PID" 2>/dev/null || true
  wait "$MONITOR_PID" "$REPORT_PID" 2>/dev/null || true
}

trap graceful_shutdown SIGTERM SIGINT

wait -n "$MONITOR_PID" "$REPORT_PID"
STATUS=$?
graceful_shutdown
exit "$STATUS"
