#!/usr/bin/env bash
set -euo pipefail

APP_HOME="${APP_HOME:-/app}"
LOG_ROOT="${LOG_ROOT:-$APP_HOME/logs}"
DATA_ROOT="${DATA_ROOT:-$APP_HOME/data}"
LOG_DIR="$LOG_ROOT/alt_futures_risk_monitor_v1"
STATE_DIR="$DATA_ROOT/alt_futures_risk_monitor_v1/runtime"
LOG_FILE="$LOG_DIR/reports.loop.log"

REPORT_LOOP_SLEEP_SECONDS="${REPORT_LOOP_SLEEP_SECONDS:-20}"
DAILY_REPORT_HOUR_UTC="${DAILY_REPORT_HOUR_UTC:-0}"
DAILY_REPORT_MINUTE_UTC="${DAILY_REPORT_MINUTE_UTC:-10}"
WEEKLY_REPORT_DAY_UTC="${WEEKLY_REPORT_DAY_UTC:-1}"
WEEKLY_REPORT_HOUR_UTC="${WEEKLY_REPORT_HOUR_UTC:-0}"
WEEKLY_REPORT_MINUTE_UTC="${WEEKLY_REPORT_MINUTE_UTC:-15}"

mkdir -p "$LOG_DIR" "$STATE_DIR"

run_job() {
  local label="$1"
  shift
  echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] run $label" | tee -a "$LOG_FILE"
  set +e
  "$@" 2>&1 | tee -a "$LOG_FILE"
  local status="${PIPESTATUS[0]}"
  set -e
  if [[ "$status" -ne 0 ]]; then
    echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $label failed with exit=$status" | tee -a "$LOG_FILE"
    return "$status"
  fi
  return 0
}

while true; do
  now_day="$(date -u +%Y%m%d)"
  now_week="$(date -u +%G-W%V)"
  now_hour="$(date -u +%-H)"
  now_minute="$(date -u +%-M)"
  now_wday="$(date -u +%u)"

  last_daily="$(cat "$STATE_DIR/last_daily_report_day.txt" 2>/dev/null || true)"
  last_weekly="$(cat "$STATE_DIR/last_weekly_report_week.txt" 2>/dev/null || true)"

  if [[ "$now_hour" == "$DAILY_REPORT_HOUR_UTC" && "$now_minute" == "$DAILY_REPORT_MINUTE_UTC" && "$last_daily" != "$now_day" ]]; then
    if run_job "daily_report" node "$APP_HOME/scripts/alt_futures_risk_report_daily.js"; then
      printf '%s\n' "$now_day" > "$STATE_DIR/last_daily_report_day.txt"
    fi
  fi

  if [[ "$now_wday" == "$WEEKLY_REPORT_DAY_UTC" && "$now_hour" == "$WEEKLY_REPORT_HOUR_UTC" && "$now_minute" == "$WEEKLY_REPORT_MINUTE_UTC" && "$last_weekly" != "$now_week" ]]; then
    if run_job "weekly_report" node "$APP_HOME/scripts/alt_futures_risk_report_weekly.js"; then
      printf '%s\n' "$now_week" > "$STATE_DIR/last_weekly_report_week.txt"
    fi
  fi

  sleep "$REPORT_LOOP_SLEEP_SECONDS"
done
