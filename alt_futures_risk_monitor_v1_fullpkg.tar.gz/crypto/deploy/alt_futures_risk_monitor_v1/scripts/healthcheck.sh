#!/usr/bin/env bash
set -euo pipefail

DATA_ROOT="${DATA_ROOT:-/app/data}"
MAX_AGE="${HEALTHCHECK_MAX_AGE_SECONDS:-900}"

current_file="$DATA_ROOT/alt_futures_risk_monitor_v1/minute_features_current.json"
snapshot_file="$DATA_ROOT/alt_futures_risk_monitor_v1/risk_eval_snapshot_1m_v1.jsonl"
event_file="$DATA_ROOT/alt_futures_risk_monitor_v1/risk_event_stream_v1.jsonl"

for file in "$current_file" "$snapshot_file" "$event_file"; do
  if [[ ! -f "$file" ]]; then
    echo "missing file: $file"
    exit 1
  fi
done

now="$(date +%s)"
mtime="$(stat -c %Y "$current_file")"
age=$(( now - mtime ))

if (( age > MAX_AGE )); then
  echo "current snapshot too old: ${age}s"
  exit 1
fi

echo "ok"
