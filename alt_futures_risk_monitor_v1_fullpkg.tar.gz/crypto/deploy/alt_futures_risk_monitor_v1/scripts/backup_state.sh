#!/usr/bin/env bash
set -euo pipefail

DEPLOY_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DATA_ROOT="${DATA_ROOT:-$DEPLOY_ROOT/runtime/data}"
REPORT_ROOT="${REPORT_ROOT:-$DEPLOY_ROOT/runtime/reports}"
LOG_ROOT="${LOG_ROOT:-$DEPLOY_ROOT/runtime/logs}"
BACKUP_ROOT="${BACKUP_ROOT:-$DEPLOY_ROOT/runtime/backups}"
KEEP_DAYS="${BACKUP_KEEP_DAYS:-7}"

mkdir -p "$BACKUP_ROOT"

timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
archive="$BACKUP_ROOT/alt_futures_risk_monitor_v1_${timestamp}.tar.gz"

paths=()
if [[ -f "$DEPLOY_ROOT/.env" ]]; then
  paths+=(".env")
fi
paths+=("docker-compose.yml" "README_部署说明.md")

tar -czf "$archive" \
  -C "$DEPLOY_ROOT" "${paths[@]}" \
  -C "$DEPLOY_ROOT/runtime" data reports logs

find "$BACKUP_ROOT" -type f -name 'alt_futures_risk_monitor_v1_*.tar.gz' -mtime +"$KEEP_DAYS" -delete || true

printf '%s\n' "$archive"

