#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "usage: $0 <backup-archive.tar.gz>"
  exit 1
fi

ARCHIVE="$1"
DEPLOY_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ ! -f "$ARCHIVE" ]]; then
  echo "archive not found: $ARCHIVE"
  exit 1
fi

echo "restore target: $DEPLOY_ROOT"
echo "make sure 'docker compose down' has been executed before restore"

tar -xzf "$ARCHIVE" -C "$DEPLOY_ROOT"

echo "restore complete"
echo "next steps:"
echo "  1. docker compose up -d"
echo "  2. docker compose logs -f alt-risk-runner"
