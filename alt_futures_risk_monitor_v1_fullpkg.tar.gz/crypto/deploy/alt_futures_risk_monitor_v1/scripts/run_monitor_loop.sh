#!/usr/bin/env bash
set -euo pipefail

APP_HOME="${APP_HOME:-/app}"
LOG_ROOT="${LOG_ROOT:-$APP_HOME/logs}"
DATA_ROOT="${DATA_ROOT:-$APP_HOME/data}"
LOG_DIR="$LOG_ROOT/alt_futures_risk_monitor_v1"
STATE_DIR="$DATA_ROOT/alt_futures_risk_monitor_v1/runtime"
LOG_FILE="$LOG_DIR/monitor.loop.log"
SLEEP_SECONDS="${MONITOR_LOOP_SLEEP_SECONDS:-5}"

mkdir -p "$LOG_DIR" "$STATE_DIR"

last_minute=""

while true; do
  current_minute="$(date -u +%Y%m%d%H%M)"
  if [[ "$current_minute" != "$last_minute" ]]; then
    echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] monitor tick $current_minute" | tee -a "$LOG_FILE"
    set +e
    node "$APP_HOME/scripts/alt_futures_risk_monitor_v1.js" 2>&1 | tee -a "$LOG_FILE"
    status="${PIPESTATUS[0]}"
    set -e
    if [[ "$status" -ne 0 ]]; then
      echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] monitor failed with exit=$status" | tee -a "$LOG_FILE"
    fi
    last_minute="$current_minute"
    printf '%s\n' "$current_minute" > "$STATE_DIR/last_monitor_minute.txt"
  fi
  sleep "$SLEEP_SECONDS"
done
