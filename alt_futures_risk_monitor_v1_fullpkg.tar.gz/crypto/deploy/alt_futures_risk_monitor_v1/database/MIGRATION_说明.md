# Migration 说明

## 当前数据库形态
- 当前 v1 **没有独立 SQL 数据库**
- 当前“数据库”是文件型状态库：
  - JSON
  - JSONL
  - Markdown 报表

## 当前建表方式
- 通过 `001_init_filesystem_store.sh` 初始化目录和基础文件
- 不存在 SQL `CREATE TABLE`

## 当前 migration 原则
1. 不原地改旧文件语义
2. 如果 schema 升级，优先：
   - 新文件名
   - 新 `schemaVersion`
   - 新 `rule_version`
3. 当前 v1 文件命名已固定为：
   - `risk_eval_snapshot_1m_v1`
   - `risk_event_stream_v1`
   - `risk_event_group_v1`
   - `risk_symbol_daily_summary_v1`
   - `risk_symbol_weekly_summary_v1`

## 当前部署口径
- 今晚不新增数据库引擎
- 明天先按文件型状态库部署
- 后续只有在运行规模和恢复复杂度明显上升后，才考虑 DB 化
