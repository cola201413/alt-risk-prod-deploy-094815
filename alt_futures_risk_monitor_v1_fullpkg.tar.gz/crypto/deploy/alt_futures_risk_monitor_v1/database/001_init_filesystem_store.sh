#!/usr/bin/env bash
set -euo pipefail

DEPLOY_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DATA_ROOT="${DATA_ROOT:-$DEPLOY_ROOT/runtime/data}"
REPORT_ROOT="${REPORT_ROOT:-$DEPLOY_ROOT/runtime/reports}"
LOG_ROOT="${LOG_ROOT:-$DEPLOY_ROOT/runtime/logs}"
BACKUP_ROOT="${BACKUP_ROOT:-$DEPLOY_ROOT/runtime/backups}"

APP_DATA_DIR="$DATA_ROOT/alt_futures_risk_monitor_v1"
APP_REPORT_DIR="$REPORT_ROOT/alt_futures_risk_monitor_v1"
APP_LOG_DIR="$LOG_ROOT/alt_futures_risk_monitor_v1"

mkdir -p \
  "$APP_DATA_DIR/books/current" \
  "$APP_DATA_DIR/books/history" \
  "$APP_DATA_DIR/market/history" \
  "$APP_DATA_DIR/orderflow_evidence_latest" \
  "$APP_DATA_DIR/orderflow_evidence_by_level" \
  "$APP_DATA_DIR/runtime" \
  "$APP_REPORT_DIR" \
  "$APP_LOG_DIR" \
  "$BACKUP_ROOT"

touch \
  "$APP_DATA_DIR/dynamic_pool_history.jsonl" \
  "$APP_DATA_DIR/minute_features.jsonl" \
  "$APP_DATA_DIR/risk_eval_snapshot_1m_v1.jsonl" \
  "$APP_DATA_DIR/risk_event_stream_v1.jsonl" \
  "$APP_DATA_DIR/risk_event_group_v1.jsonl"

if [[ ! -f "$APP_DATA_DIR/shared_evidence_state_current.json" ]]; then
  printf '{\n  "episodes": {}\n}\n' > "$APP_DATA_DIR/shared_evidence_state_current.json"
fi

printf 'initialized filesystem store at %s\n' "$APP_DATA_DIR"
