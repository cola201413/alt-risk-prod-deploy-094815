# 币安山寨币风险监控 v1 部署说明

## 1. 部署定位
- 当前只部署：`alt_futures_risk_monitor_v1`
- 这是最小生产可运行版：
  - 持续运行
  - 可备份
  - 可恢复
  - 可滚动观察
- 当前不做：
  - 新功能
  - 规则调整
  - 前台
  - 架构重构

## 2. 当前版本基线
- 分支：`codex/stability-handover`
- commit：`ae00404330d8d1a6b288ebed9581f46b697bd476`
- 工作区：`dirty`
- 默认观察对象：`DOGEUSDT / SOLUSDT`
- 重点风险家族：`thin_book_move / sell_pressure`

## 3. 当前运行形态
- 运行方式：单容器 Node 运行器
- 采集器、规则引擎、日报/周报调度都在同一容器里
- 当前没有单独数据库服务
- 当前“数据库”是文件型状态库：
  - `data/`
  - `reports/`
  - `logs/`
  - `backups/`

## 4. 新机器从 0 到启动
### 4.1 安装前提
新服务器需安装：
- Docker Engine
- Docker Compose Plugin
- Git

### 4.2 拉代码
```bash
git clone <your-repo-url> /opt/crypto
cd /opt/crypto
git checkout codex/stability-handover
git rev-parse HEAD
```

确认 commit 为：
- `ae00404330d8d1a6b288ebed9581f46b697bd476`

### 4.3 进入部署目录
```bash
cd /opt/crypto/deploy/alt_futures_risk_monitor_v1
cp .env.example .env
chmod +x ./database/001_init_filesystem_store.sh ./scripts/*.sh
```

### 4.4 编辑环境变量
至少检查：
- `TZ`
- `BINANCE_PROXY_URL` / `ALT_RISK_PROXY_URL`（如云上网络需要代理）
- `ALT_RISK_EXCLUDED_SYMBOLS`
- `DAILY_REPORT_*`
- `WEEKLY_REPORT_*`

### 4.5 初始化“数据库”
当前版本无独立 SQL 数据库，初始化命令为文件型状态库初始化：
```bash
./database/001_init_filesystem_store.sh
```

### 4.6 构建并启动
```bash
docker compose build
docker compose up -d
```

### 4.7 确认服务正常
```bash
docker compose ps
docker compose logs -f alt-risk-runner
docker compose exec alt-risk-runner /app/deploy/alt_futures_risk_monitor_v1/scripts/healthcheck.sh
```

健康运行时应能看到：
- `monitor:alt-futures-risk:v1` 周期输出
- `report:alt-futures-risk:daily` / `weekly` 按设定时间运行
- `data/alt_futures_risk_monitor_v1` 下文件持续更新

## 5. 如何启动采集器 / 规则引擎 / 数据库
### 5.1 一键方式
```bash
docker compose up -d
```

含义：
- 采集器：由 `run_monitor_loop.sh` 按 1 分钟闭合节奏持续触发
- 规则引擎：跟采集器在同一进程链内执行
- 数据库：当前是文件型状态库，由 `001_init_filesystem_store.sh` 初始化

### 5.2 手动执行方式
进入容器后可以单独执行：
```bash
docker compose exec alt-risk-runner node scripts/alt_futures_risk_monitor_v1.js
docker compose exec alt-risk-runner node scripts/alt_futures_risk_report_daily.js
docker compose exec alt-risk-runner node scripts/alt_futures_risk_report_weekly.js
docker compose exec alt-risk-runner node scripts/alt_futures_risk_replay_v1.js
```

## 6. 如何停止 / 重启
### 停止
```bash
docker compose down
```

### 重启
```bash
docker compose restart
```

### 重建后重启
```bash
docker compose build --no-cache
docker compose up -d
```

## 7. 如何查看日志
### 容器总日志
```bash
docker compose logs -f alt-risk-runner
```

### 宿主机持久化日志目录
```bash
./runtime/logs/alt_futures_risk_monitor_v1/
```

关键日志文件：
- `monitor.loop.log`
- `reports.loop.log`

## 8. 如何确认服务正常运行
至少确认 5 件事：
1. `docker compose ps` 显示容器为 `healthy`
2. `runtime/data/alt_futures_risk_monitor_v1/dynamic_pool_current.json` 持续更新
3. `runtime/data/alt_futures_risk_monitor_v1/risk_eval_snapshot_1m_v1.jsonl` 有新增行
4. `runtime/data/alt_futures_risk_monitor_v1/risk_event_stream_v1.jsonl` 正常产出事件
5. `runtime/reports/alt_futures_risk_monitor_v1/*.json` 能按日/周更新

## 9. 数据库与初始化
### 建表脚本
- `database/001_init_filesystem_store.sh`

### migration 说明
- `database/MIGRATION_说明.md`

### 初始化命令
```bash
./database/001_init_filesystem_store.sh
```

### 每日备份
```bash
./scripts/backup_state.sh
```

### 恢复
```bash
docker compose down
./scripts/restore_state.sh ./runtime/backups/<archive>.tar.gz
docker compose up -d
```

## 10. 明天部署边界
明天部署只做：
- 1 台云服务器
- 持续运行
- 可备份
- 可恢复

明天不做：
- 新功能
- 新规则
- 前台
- 执行层
- 架构重构

## 11. 备忘
- 当前 `Binance 418` 仍属于外部环境 / 运行风险
- 当前 `adl_risk_level` 仍为 public 可得性受限降级项
- 当前 liquidation 增强仍是字段保留 + 质量降级，不是完整强确认
