# altFuturesRiskMonitor shared_feature_export

本目录预留给 AWS 山寨风控共享数据平面输出统一 market feature snapshot。

首轮只做目录占位，不接真实导出逻辑。

计划中的导出内容：

* `symbol`
* `event_ts_ms`
* `bar_close_ts_ms`
* `spread_bps`
* `depth_bid_usd_25bp`
* `depth_ask_usd_25bp`
* `depth_total_usd_25bp`
* `impact_worst_50k_bps`
* `buy_sell_ratio_5m`
* `buy_sell_ratio_15m`
* `oi_change_15m_pct`
* `oi_change_1h_pct`
* `liq_intensity_5m_z`
* `adl_risk_level`
* `orderbook_sync_ok`
* `data_quality`
* `degrade_reasons`
