# altFuturesRiskMonitor shared_evidence_export

本目录预留给共享订单流证据导出。

首轮计划：

* 先走 JSON snapshot 导出
* 后续如有必要，再升级为只读内部 API

计划中的导出形态：

* `orderflow_evidence_latest/{symbol}.json`
* `orderflow_evidence_by_level/{symbol}_{level_id}.json`

固定边界：

* 山寨风控共享层是唯一生产者
* 主动交易只读消费
* 共享证据不能直接映射成主动交易主判断
