# altFuturesRiskMonitor shared_contracts

本目录是山寨风控侧的共享合同占位目录。

当前规则：

* 共享合同的 canonical 文档放在 `D:\DEV\PROJECT_HANDBOOK\40_分析与数据\`
* 本目录只保留工程引用说明与 manifest
* 山寨风控侧是共享证据的唯一生产者

当前冻结文档：

* `主动交易 × 山寨风控 协同底座方案 v1.md`
* `共享市场与订单流字段合同 v1.md`
* `共享订单流证据合同 v1.md`
* `主动交易接入边界 v1.md`
* `统一样本与 Replay 合同 v1.md`
* `AWS 部署后协同任务拆分 v1.md`
