const { createLogger } = require("../lib/runtime");
const { generateAltFuturesRiskReport } = require("../lib/altFuturesRiskMonitor/reports");

function main() {
  const logger = createLogger(process.env.ALT_RISK_LOG_LEVEL || "info");
  const report = generateAltFuturesRiskReport("daily", logger);
  process.stdout.write(`${JSON.stringify({
    ok: true,
    entry: "report:alt-futures-risk:daily",
    summaryType: report.summaryType,
    count: report.count,
    topSymbols: (report.symbols || []).slice(0, 5).map((row) => ({
      symbol: row.symbol,
      daily_max_severity: row.daily_max_severity,
      daily_max_score: row.daily_max_score,
      daily_event_count: row.daily_event_count,
      daily_core_count: row.daily_core_count,
      daily_total_active_min: row.daily_total_active_min,
      main_family_of_day: row.main_family_of_day,
      top_reason_of_day: row.top_reason_of_day,
      needs_manual_review: row.needs_manual_review,
    })),
  }, null, 2)}\n`);
}

main();
