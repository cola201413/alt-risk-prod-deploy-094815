const { createLogger } = require("../lib/runtime");
const { collectAltFuturesRiskSnapshot } = require("../lib/altFuturesRiskMonitor/collector");
const { evaluateAltFuturesRiskRules } = require("../lib/altFuturesRiskMonitor/rules");
const { applyAltFuturesRiskEvents } = require("../lib/altFuturesRiskMonitor/events");
const { exportSharedEvidence } = require("../lib/altFuturesRiskMonitor/sharedEvidence");

function parseSymbolsOverride(argv) {
  const raw = argv.find((arg) => String(arg || "").startsWith("--symbols="));
  if (!raw) return null;
  const value = raw.split("=")[1] || "";
  const rows = value.split(",").map((row) => String(row || "").trim().toUpperCase()).filter(Boolean);
  return rows.length > 0 ? rows : null;
}

function parseSharedSymbols() {
  return String(process.env.ALT_RISK_SHARED_EXPORT_SYMBOLS || "BTCUSDT")
    .split(",")
    .map((arg) => String(arg || "").trim().toUpperCase())
    .filter(Boolean);
}

async function main() {
  const logger = createLogger(process.env.ALT_RISK_LOG_LEVEL || "info");
  const symbolsOverride = parseSymbolsOverride(process.argv.slice(2));
  const sharedSymbols = parseSharedSymbols();
  const snapshot = await collectAltFuturesRiskSnapshot({
    symbolsOverride,
    logger,
  });
  const evaluations = evaluateAltFuturesRiskRules(snapshot.features);
  const eventResult = applyAltFuturesRiskEvents(evaluations, logger);
  const sharedSnapshot = await collectAltFuturesRiskSnapshot({
    symbolsOverride: sharedSymbols,
    logger,
    persistOutputs: false,
  });
  const sharedEvaluations = evaluateAltFuturesRiskRules(sharedSnapshot.features);
  const sharedExports = [];
  for (const feature of sharedSnapshot.features) {
    const evaluation = sharedEvaluations.find((row) => row.symbol === feature.symbol);
    if (!evaluation) continue;
    sharedExports.push(exportSharedEvidence({ feature, evaluation, logger }));
  }
  const activeRules = evaluations.flatMap((row) => row.rules.filter((rule) => rule.active));
  const output = {
    ok: true,
    entry: "monitor:alt-futures-risk:v1",
    purpose: "binance usdsm futures structural risk monitor",
    collectedSymbols: snapshot.summary.collectedCount,
    failedSymbols: snapshot.summary.failureCount,
    grading: ["none", "observe", "composite", "core"],
    activeRuleCount: activeRules.length,
    activeSymbols: eventResult.groups.length,
    topGroups: eventResult.groups.slice(0, 10).map((row) => ({
      symbol: row.symbol,
      event_group_id: row.event_group_id,
      primary_family: row.primary_family,
      latest_severity: row.latest_severity,
      latest_score: row.latest_score,
      event_count_total: row.event_count_total,
      latest_reason: row.latest_reason,
    })),
    activeRules: activeRules
      .sort((a, b) => Number(b.score || 0) - Number(a.score || 0))
      .slice(0, 20)
      .map((row) => ({
        symbol: row.symbol,
        ruleKey: row.ruleKey,
        severity: row.severity,
        score: row.score,
        summary: row.summary,
        family: row.ruleFamily,
      })),
    sharedEvidenceExports: sharedExports,
  };
  process.stdout.write(`${JSON.stringify(output, null, 2)}\n`);
}

main().catch((err) => {
  process.stderr.write(`${JSON.stringify({
    ok: false,
    entry: "monitor:alt-futures-risk:v1",
    message: String(err?.message || err || "monitor failed"),
  }, null, 2)}\n`);
  process.exitCode = 1;
});
