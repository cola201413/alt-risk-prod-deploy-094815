const { createLogger } = require("../lib/runtime");
const { generateAltFuturesRiskReport } = require("../lib/altFuturesRiskMonitor/reports");

function main() {
  const logger = createLogger(process.env.ALT_RISK_LOG_LEVEL || "info");
  const report = generateAltFuturesRiskReport("weekly", logger);
  process.stdout.write(`${JSON.stringify({
    ok: true,
    entry: "report:alt-futures-risk:weekly",
    summaryType: report.summaryType,
    count: report.count,
    topSymbols: (report.symbols || []).slice(0, 5),
  }, null, 2)}\n`);
}

main();
