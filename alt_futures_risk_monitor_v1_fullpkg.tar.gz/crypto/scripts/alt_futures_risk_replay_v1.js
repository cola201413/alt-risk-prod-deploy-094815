const { createLogger } = require("../lib/runtime");
const { replayAltFuturesRisk } = require("../lib/altFuturesRiskMonitor/replay");

function parseSymbolsOverride(argv) {
  const raw = argv.find((arg) => String(arg || "").startsWith("--symbols="));
  if (!raw) return null;
  const value = raw.split("=")[1] || "";
  const rows = value.split(",").map((row) => String(row || "").trim().toUpperCase()).filter(Boolean);
  return rows.length > 0 ? rows : null;
}

function main() {
  const logger = createLogger(process.env.ALT_RISK_LOG_LEVEL || "info");
  const symbolsOverride = parseSymbolsOverride(process.argv.slice(2));
  const replay = replayAltFuturesRisk({ logger, symbolsOverride });
  process.stdout.write(`${JSON.stringify({
    ok: true,
    entry: "replay:alt-futures-risk:v1",
    rowsReplayed: replay.rowsReplayed,
    symbolCount: replay.symbolCount,
    topSymbols: replay.symbols.slice(0, 10),
  }, null, 2)}\n`);
}

main();
